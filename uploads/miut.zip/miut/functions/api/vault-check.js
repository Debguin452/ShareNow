/**
 * functions/api/vault-check.js
 *
 * Validates vault passkey against VAULT_PASSKEY env var.
 * Returns a short-lived session token on match.
 *
 * POST /api/vault-check  { "key": "..." }
 * → { "vault": true, "token": "..." }   on match
 * → { "vault": false }                  on mismatch (same timing to prevent timing attacks)
 *
 * Set in Cloudflare Pages dashboard: VAULT_PASSKEY = your-secret-passphrase
 */
'use strict';

const CORS = { 'Access-Control-Allow-Origin': 'same-origin' };

async function _timingSafeEqual(a, b) {
  // Use SubtleCrypto HMAC to prevent timing attacks on string comparison
  const key = await crypto.subtle.generateKey({ name:'HMAC', hash:'SHA-256' }, false, ['sign']);
  const [sa, sb] = await Promise.all([
    crypto.subtle.sign('HMAC', key, new TextEncoder().encode(a)),
    crypto.subtle.sign('HMAC', key, new TextEncoder().encode(b)),
  ]);
  const va = new Uint8Array(sa), vb = new Uint8Array(sb);
  if (va.length !== vb.length) return false;
  let diff = 0;
  for (let i = 0; i < va.length; i++) diff |= va[i] ^ vb[i];
  return diff === 0;
}

export async function onRequest(ctx) {
  const { request, env } = ctx;

  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
  if (request.method !== 'POST')    return new Response('POST only', { status: 405 });

  const vaultKey = env?.VAULT_PASSKEY || '';
  if (!vaultKey) return new Response(JSON.stringify({ vault: false }), {
    status: 200, headers: { 'Content-Type': 'application/json', ...CORS },
  });

  let body;
  try { body = await request.json(); } catch { return new Response(JSON.stringify({ vault: false }), { status: 200, headers: { 'Content-Type': 'application/json', ...CORS } }); }

  const match = await _timingSafeEqual(body?.key || '', vaultKey);

  if (!match) {
    // Consistent response to prevent enumeration
    return new Response(JSON.stringify({ vault: false }), {
      status: 200, headers: { 'Content-Type': 'application/json', ...CORS },
    });
  }

  // Generate a short-lived session token (valid 1hr, stored in KV if available)
  const token = Array.from(crypto.getRandomValues(new Uint8Array(24)))
    .map(b => b.toString(16).padStart(2,'0')).join('');
  const expiry = Date.now() + 3600_000;

  if (env?.MIUT_KV) {
    await env.MIUT_KV.put(`vault_token:${token}`, '1', { expirationTtl: 3600 }).catch(() => {});
  }

  return new Response(JSON.stringify({ vault: true, token, expiry }), {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-store',
      ...CORS,
    },
  });
}
