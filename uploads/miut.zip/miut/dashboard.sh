#!/data/data/com.termux/files/usr/bin/bash

SCRIPT_DIR="/storage/emulated/0/My_codes"
BASE="https://miutchat.pages.dev"
PATHS=("login" "signup" "api" "admin" "test" "dev" "backup")
LOGFILE="dashboard.log"
SLEEP=10

# Colors
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
CYAN='\033[1;36m'
RESET='\033[0m'

while true; do
  clear
  echo -e "${CYAN}========================================${RESET}"
  echo -e "${CYAN}   MiutChat Dashboard${RESET}"
  date
  echo -e "${CYAN}========================================${RESET}"

  echo ""
  echo -e "${YELLOW}[1] PATH SCAN${RESET}"

  for path in "${PATHS[@]}"; do
    URL="$BASE/$path"

    STATUS=$(curl -o /dev/null -s -w "%{http_code}" "$URL")
    FINAL=$(curl -Ls -o /dev/null -w "%{url_effective}" "$URL")

    if [ "$STATUS" = "200" ]; then
      echo -e "/$path -> ${GREEN}$STATUS${RESET}"
    elif [ "$STATUS" = "404" ]; then
      echo -e "/$path -> ${CYAN}$STATUS${RESET}"
    elif [ "$STATUS" = "302" ]; then
      echo -e "/$path -> ${YELLOW}$STATUS ${RESET} $FINAL"
    else
      echo -e "/$path -> ${RED}$STATUS${RESET}"
    fi
  done

  echo ""
  echo -e "${YELLOW}[2] MAIN STATUS${RESET}"

  STATUS=$(curl -o /dev/null -s -w "%{http_code}" "$BASE")
  TIME=$(curl -o /dev/null -s -w "%{time_total}" "$BASE")

  if [ "$STATUS" = "200" ]; then
    echo -e "Status: ${GREEN}$STATUS${RESET} | Time: ${TIME}s"
  elif [ "$STATUS" = "503" ]; then
    echo -e "Status: ${RED}$STATUS (MAINTENANCE)${RESET}"
  else
    echo -e "Status: ${RED}$STATUS${RESET}"
  fi

  echo ""
  echo -e "${YELLOW}[3] SECURITY HEADERS${RESET}"
  curl -s -I "$BASE" | grep -E "content-security-policy|x-frame-options|strict-transport-security"

  echo ""
  echo -e "${YELLOW}[4] SERVICE WORKER${RESET}"
  SW=$(curl -s -I "$BASE/sw.min.js" | grep "content-type")

  if echo "$SW" | grep -q "javascript"; then
    echo -e "SW OK ${GREEN}$SW${RESET}"
  else
    echo -e "SW ERROR ${RED}$SW${RESET}"
  fi

  echo ""
  echo -e "${YELLOW}[5] PERFORMANCE${RESET}"
  curl -o /dev/null -s -w "DNS: %{time_namelookup}s | Connect: %{time_connect}s | Total: %{time_total}s\n" "$BASE"

  echo ""
  echo -e "Next refresh in $SLEEP sec..."

  sleep $SLEEP
done
